<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="zona1_tileset" tilewidth="16" tileheight="16" tilecount="72" columns="8">
 <image source="../../assets/sprites/zona1_tileset.png" width="128" height="144"/>
</tileset>
