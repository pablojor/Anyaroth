<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="boss1_tileset" tilewidth="16" tileheight="16" tilecount="208" columns="16">
 <image source="../../assets/sprites/boss1_tileset.png" width="256" height="208"/>
</tileset>
